--
-- PostgreSQL database dump
--

\restrict 8dXrqq7ZsxZNJSj4SFDDyzn1XyHSdHUJIkm7CiR6KCVdwpMBaddyB5REf6Yx2QB

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_role_id_fkey;
ALTER TABLE IF EXISTS ONLY public.shift_assignments DROP CONSTRAINT IF EXISTS shift_assignments_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.shift_assignments DROP CONSTRAINT IF EXISTS shift_assignments_shift_id_fkey;
ALTER TABLE IF EXISTS ONLY public.deliveries DROP CONSTRAINT IF EXISTS deliveries_volunteer_id_fkey;
ALTER TABLE IF EXISTS ONLY public.deliveries DROP CONSTRAINT IF EXISTS deliveries_family_id_fkey;
ALTER TABLE IF EXISTS ONLY public.batches DROP CONSTRAINT IF EXISTS batches_product_id_fkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_email_key;
ALTER TABLE IF EXISTS ONLY public.shifts DROP CONSTRAINT IF EXISTS shifts_pkey;
ALTER TABLE IF EXISTS ONLY public.shift_assignments DROP CONSTRAINT IF EXISTS shift_assignments_shift_id_user_id_key;
ALTER TABLE IF EXISTS ONLY public.shift_assignments DROP CONSTRAINT IF EXISTS shift_assignments_pkey;
ALTER TABLE IF EXISTS ONLY public.roles DROP CONSTRAINT IF EXISTS roles_pkey;
ALTER TABLE IF EXISTS ONLY public.roles DROP CONSTRAINT IF EXISTS roles_name_key;
ALTER TABLE IF EXISTS ONLY public.products DROP CONSTRAINT IF EXISTS products_pkey;
ALTER TABLE IF EXISTS ONLY public.nevera_rations DROP CONSTRAINT IF EXISTS nevera_rations_pkey;
ALTER TABLE IF EXISTS ONLY public.nevera_rations DROP CONSTRAINT IF EXISTS nevera_rations_date_key;
ALTER TABLE IF EXISTS ONLY public.families DROP CONSTRAINT IF EXISTS families_reference_code_key;
ALTER TABLE IF EXISTS ONLY public.families DROP CONSTRAINT IF EXISTS families_pkey;
ALTER TABLE IF EXISTS ONLY public.derivations DROP CONSTRAINT IF EXISTS derivations_reference_code_key;
ALTER TABLE IF EXISTS ONLY public.derivations DROP CONSTRAINT IF EXISTS derivations_pkey;
ALTER TABLE IF EXISTS ONLY public.deliveries DROP CONSTRAINT IF EXISTS deliveries_pkey;
ALTER TABLE IF EXISTS ONLY public.batches DROP CONSTRAINT IF EXISTS batches_pkey;
ALTER TABLE IF EXISTS public.roles ALTER COLUMN id DROP DEFAULT;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.shifts;
DROP TABLE IF EXISTS public.shift_assignments;
DROP SEQUENCE IF EXISTS public.roles_id_seq;
DROP TABLE IF EXISTS public.roles;
DROP TABLE IF EXISTS public.products;
DROP TABLE IF EXISTS public.nevera_rations;
DROP TABLE IF EXISTS public.families;
DROP TABLE IF EXISTS public.derivations;
DROP TABLE IF EXISTS public.deliveries;
DROP TABLE IF EXISTS public.batches;
DROP EXTENSION IF EXISTS "uuid-ossp";
--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: batches; Type: TABLE; Schema: public; Owner: xama_user
--

CREATE TABLE public.batches (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    product_id uuid,
    origin character varying(100) NOT NULL,
    quantity numeric(10,2) NOT NULL,
    expiry_date date NOT NULL,
    status character varying(20) DEFAULT 'disponible'::character varying,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT batches_quantity_check CHECK ((quantity >= (0)::numeric))
);


ALTER TABLE public.batches OWNER TO xama_user;

--
-- Name: deliveries; Type: TABLE; Schema: public; Owner: xama_user
--

CREATE TABLE public.deliveries (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    family_id uuid,
    delivery_date date NOT NULL,
    site character varying(50) NOT NULL,
    volunteer_id uuid,
    status character varying(20) DEFAULT 'pendiente'::character varying,
    notes text,
    checked_in_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.deliveries OWNER TO xama_user;

--
-- Name: derivations; Type: TABLE; Schema: public; Owner: xama_user
--

CREATE TABLE public.derivations (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    reference_code character varying(50) NOT NULL,
    person_name character varying(255),
    origin character varying(100) NOT NULL,
    reason text,
    rations integer DEFAULT 1,
    status character varying(20) DEFAULT 'pendiente'::character varying,
    served_at timestamp with time zone,
    notes text,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT derivations_rations_check CHECK ((rations >= 1))
);


ALTER TABLE public.derivations OWNER TO xama_user;

--
-- Name: families; Type: TABLE; Schema: public; Owner: xama_user
--

CREATE TABLE public.families (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    reference_code character varying(50) NOT NULL,
    address text,
    phone character varying(20),
    adults integer DEFAULT 0,
    minors integer DEFAULT 0,
    dietary_restrictions text,
    notes text,
    site character varying(50),
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT families_adults_check CHECK ((adults >= 0)),
    CONSTRAINT families_minors_check CHECK ((minors >= 0))
);


ALTER TABLE public.families OWNER TO xama_user;

--
-- Name: nevera_rations; Type: TABLE; Schema: public; Owner: xama_user
--

CREATE TABLE public.nevera_rations (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    date date NOT NULL,
    target_rations integer DEFAULT 20,
    served_rations integer DEFAULT 0,
    notes text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.nevera_rations OWNER TO xama_user;

--
-- Name: products; Type: TABLE; Schema: public; Owner: xama_user
--

CREATE TABLE public.products (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    category character varying(100),
    unit character varying(20) DEFAULT 'kg'::character varying,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.products OWNER TO xama_user;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: xama_user
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.roles OWNER TO xama_user;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: xama_user
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.roles_id_seq OWNER TO xama_user;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: xama_user
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: shift_assignments; Type: TABLE; Schema: public; Owner: xama_user
--

CREATE TABLE public.shift_assignments (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    shift_id uuid,
    user_id uuid,
    hours numeric(4,2),
    attended boolean DEFAULT false,
    notes text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.shift_assignments OWNER TO xama_user;

--
-- Name: shifts; Type: TABLE; Schema: public; Owner: xama_user
--

CREATE TABLE public.shifts (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    shift_date date NOT NULL,
    site character varying(50) NOT NULL,
    role character varying(30) NOT NULL,
    start_time time without time zone NOT NULL,
    end_time time without time zone NOT NULL,
    capacity integer DEFAULT 1,
    notes text,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT shifts_capacity_check CHECK ((capacity >= 1))
);


ALTER TABLE public.shifts OWNER TO xama_user;

--
-- Name: users; Type: TABLE; Schema: public; Owner: xama_user
--

CREATE TABLE public.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    full_name character varying(255) NOT NULL,
    role_id integer,
    site character varying(50),
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.users OWNER TO xama_user;

--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: xama_user
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Data for Name: batches; Type: TABLE DATA; Schema: public; Owner: xama_user
--

COPY public.batches (id, product_id, origin, quantity, expiry_date, status, created_at) FROM stdin;
1ea68835-b418-4935-8149-571589d17706	5d90cee8-77c7-4353-bf48-8eeb999027a9	comercio_local	15.82	2026-10-27	disponible	2026-09-27 11:58:10.709968+00
45099312-e890-43df-b9b2-f109b74de8b8	12569c23-6848-40c7-a210-320d1042706f	donacion_corporativa	15.44	2026-10-04	disponible	2026-09-27 11:58:10.709968+00
dcc3eef1-3a60-4b86-905e-d19fc6e6e9fb	73de23c9-56b1-48b4-8072-6056ebf3d02a	comercio_local	24.76	2026-10-02	disponible	2026-09-27 11:58:10.709968+00
a2436cbe-bad7-4daf-8dc6-421a69ff3723	48615bef-c678-4b7d-a7bc-8d80b0a14ed7	donacion_corporativa	7.37	2026-10-17	disponible	2026-09-27 11:58:10.709968+00
0d4ea55d-2db9-4281-948d-47b24cf7a83a	73de23c9-56b1-48b4-8072-6056ebf3d02a	campana_solidaria	9.56	2026-10-11	disponible	2026-09-27 11:58:10.709968+00
08fb7ca1-6b9c-432f-8551-51b5766dd0bb	b9e72069-5fff-4637-be55-7af944773a18	donacion_corporativa	33.05	2026-10-11	disponible	2026-09-27 11:58:10.709968+00
5a575eb4-58ee-4baf-9237-76eec439e44c	6af072c3-3ec0-44d7-9935-144a4ee9550c	excedente_agricola	3.58	2026-11-26	disponible	2026-09-27 11:58:10.709968+00
197a6de0-beee-4319-8a6e-4617f7a55258	a5afd2f8-6fae-4b86-8166-7458c5baa1b8	donacion_corporativa	26.56	2026-10-17	disponible	2026-09-27 11:58:10.709968+00
9c80ffae-8936-43e4-90e5-8b72dc6738cb	0fd996a9-a697-4cdf-b715-4f97931e8df0	donacion_corporativa	11.33	2026-10-04	disponible	2026-09-27 11:58:10.709968+00
fa4b1b14-dc16-47cf-9094-23c2b4d04137	48615bef-c678-4b7d-a7bc-8d80b0a14ed7	campana_solidaria	11.25	2026-11-26	disponible	2026-09-27 11:58:10.709968+00
97ab5480-8eb6-470c-b64e-97e72a598857	9db83ff6-78d3-463c-83a0-26c406715fa3	campana_solidaria	16.58	2026-10-04	disponible	2026-09-27 11:58:10.709968+00
4db1ca43-5558-4ac0-9cc3-73b326d157d5	f0e267b9-1ccd-42a5-8013-f99b2c17fc35	campana_solidaria	20.25	2026-09-29	disponible	2026-09-27 11:58:10.709968+00
e8b557ea-b029-4bf4-975a-4ee5e1fd24bc	5e490df4-0252-4fc1-8f1a-c287b63adda6	donacion_corporativa	25.47	2026-10-17	disponible	2026-09-27 11:58:10.709968+00
998e80c1-59ce-4a6c-b027-7d4408b08227	bb033dce-3da9-4fc3-a9c5-cd336326d0dd	comercio_local	16.01	2026-11-26	disponible	2026-09-27 11:58:10.709968+00
80839955-21a2-4f03-bbaa-64171581f849	0fd996a9-a697-4cdf-b715-4f97931e8df0	campana_solidaria	10.81	2026-11-11	disponible	2026-09-27 11:58:10.709968+00
1c55ec82-0672-4fd6-a773-93d61af60bc9	970b1df7-32e8-45d3-9d39-32f84b5bd476	comercio_local	27.59	2026-11-11	disponible	2026-09-27 11:58:10.709968+00
db11e681-c537-4a80-8293-34fa21875c61	73de23c9-56b1-48b4-8072-6056ebf3d02a	excedente_agricola	5.35	2026-10-17	disponible	2026-09-27 11:58:10.709968+00
7eec7d01-9c22-4a30-a5ca-acfadf50bd87	315fba23-0a03-40dd-b639-7b5ec70b9c0f	comida_cocinada	1.13	2026-10-07	disponible	2026-09-27 11:58:10.709968+00
6c680a10-91df-47a8-94be-bdfdd8a44b22	ec93d5df-177b-41e2-b3e0-5ccbcbf5cce3	donacion_corporativa	20.80	2026-09-30	disponible	2026-09-27 11:58:10.709968+00
ab979dcc-6c77-4247-a95c-f7e302490d64	d25787fb-aee2-4ff5-ad28-ce9c04a96300	campana_solidaria	24.75	2026-10-02	disponible	2026-09-27 11:58:10.709968+00
aafd5566-48f0-4b58-9382-33fcdac43b14	12569c23-6848-40c7-a210-320d1042706f	donacion_corporativa	22.04	2026-11-11	disponible	2026-09-27 11:58:10.709968+00
57e3a38d-4eb0-40a4-b516-7064101601bb	970b1df7-32e8-45d3-9d39-32f84b5bd476	campana_solidaria	13.64	2026-09-29	disponible	2026-09-27 11:58:10.709968+00
f8e390c4-738c-4855-bce1-8f818c915d0d	5e490df4-0252-4fc1-8f1a-c287b63adda6	excedente_agricola	35.27	2026-10-07	disponible	2026-09-27 11:58:10.709968+00
b5b179eb-4caa-4cc3-8875-61d301d3a83b	5d90cee8-77c7-4353-bf48-8eeb999027a9	comercio_local	10.39	2026-11-26	disponible	2026-09-27 11:58:10.709968+00
56dc0c1c-7a6d-48da-85e4-b6ca5fe2c062	e2fb1c66-65d1-4e91-b3c1-5000a15cc777	comercio_local	29.54	2026-09-30	disponible	2026-09-27 11:58:10.709968+00
6f67d28f-fdb6-4c58-9eb9-bf1908f78a9b	48615bef-c678-4b7d-a7bc-8d80b0a14ed7	donacion_corporativa	6.01	2026-10-27	disponible	2026-09-27 11:58:10.709968+00
2b9443e3-ae61-4e6d-9d7b-6d0f62945681	48615bef-c678-4b7d-a7bc-8d80b0a14ed7	donacion_corporativa	11.34	2026-11-26	disponible	2026-09-27 11:58:10.709968+00
ef9910c3-e03c-49e3-af76-ebe5d7b8e832	9db83ff6-78d3-463c-83a0-26c406715fa3	donacion_corporativa	37.23	2026-10-04	disponible	2026-09-27 11:58:10.709968+00
ffdec047-1420-49c3-b53e-d0801a6056b6	d25787fb-aee2-4ff5-ad28-ce9c04a96300	comida_cocinada	39.81	2026-10-11	disponible	2026-09-27 11:58:10.709968+00
f4158ba1-33cc-46d4-a486-bd875635c75e	0fd996a9-a697-4cdf-b715-4f97931e8df0	campana_solidaria	18.61	2026-10-04	disponible	2026-09-27 11:58:10.709968+00
d1b7d803-e17c-4dcc-a121-7b7a50d2b5e6	5d90cee8-77c7-4353-bf48-8eeb999027a9	comercio_local	14.19	2026-11-26	disponible	2026-09-27 11:58:10.709968+00
91a05f83-c26d-4ff1-940c-90a878dd0382	48615bef-c678-4b7d-a7bc-8d80b0a14ed7	donacion_corporativa	23.95	2026-09-29	disponible	2026-09-27 11:58:10.709968+00
5506d035-f1b9-40e2-b033-8eda050c2b0f	e2fb1c66-65d1-4e91-b3c1-5000a15cc777	comercio_local	9.93	2026-09-29	disponible	2026-09-27 11:58:10.709968+00
a9901ef4-d035-4858-b322-475f90b892f6	a5afd2f8-6fae-4b86-8166-7458c5baa1b8	comercio_local	21.05	2026-10-07	disponible	2026-09-27 11:58:10.709968+00
b1ddf036-dbc5-4b11-b565-88af54059887	93b92c23-f2ec-4681-a17c-981cd343db64	donacion_corporativa	22.03	2026-11-26	disponible	2026-09-27 11:58:10.709968+00
7b21c762-0323-4b17-90cc-27c7b86c57db	f76b0aff-8aa7-4a71-bf32-47c5d2c3c02e	comida_cocinada	10.48	2026-10-27	disponible	2026-09-27 11:58:10.709968+00
bd156251-e7c7-42e1-8b66-0bcc029c6af3	9db83ff6-78d3-463c-83a0-26c406715fa3	donacion_corporativa	4.68	2026-10-17	disponible	2026-09-27 11:58:10.709968+00
a05bf6da-1917-4938-98ab-e52411e3a6ff	12569c23-6848-40c7-a210-320d1042706f	comida_cocinada	17.03	2026-09-29	disponible	2026-09-27 11:58:10.709968+00
9ba27bd3-4369-470c-bce1-8e016b1281d2	5e490df4-0252-4fc1-8f1a-c287b63adda6	comercio_local	16.70	2026-10-11	disponible	2026-09-27 11:58:10.709968+00
e77dcbac-97b2-4d23-8760-24d9aa14efea	5e490df4-0252-4fc1-8f1a-c287b63adda6	donacion_corporativa	8.47	2026-11-11	disponible	2026-09-27 11:58:10.709968+00
86ba44d4-dfe0-42c5-b296-af65a6f3a8c5	0fd996a9-a697-4cdf-b715-4f97931e8df0	donacion_corporativa	17.45	2026-10-07	disponible	2026-09-27 11:58:10.709968+00
9fa75ff6-7852-42df-9f7c-381e02c738b2	0fd996a9-a697-4cdf-b715-4f97931e8df0	donacion_corporativa	35.10	2026-09-30	disponible	2026-09-27 11:58:10.709968+00
4c1e3300-4fa4-47d9-a152-f2597c2f6e5c	0fd996a9-a697-4cdf-b715-4f97931e8df0	campana_solidaria	4.82	2026-11-11	disponible	2026-09-27 11:58:10.709968+00
f32cd31d-7b23-42b9-91e2-564181b6d876	970b1df7-32e8-45d3-9d39-32f84b5bd476	comercio_local	37.13	2026-10-04	disponible	2026-09-27 11:58:10.709968+00
6b250e63-d7c0-434b-982e-bc48b3aaf704	315fba23-0a03-40dd-b639-7b5ec70b9c0f	comida_cocinada	19.94	2026-10-04	disponible	2026-09-27 11:58:10.709968+00
bcffbe6f-2de4-417b-979c-a9c807c6f955	6af072c3-3ec0-44d7-9935-144a4ee9550c	comercio_local	7.42	2026-09-29	disponible	2026-09-27 11:58:10.709968+00
a7d7f025-ae4f-4cd7-9e36-4e0e1c08faf8	6af072c3-3ec0-44d7-9935-144a4ee9550c	excedente_agricola	37.13	2026-10-27	disponible	2026-09-27 11:58:10.709968+00
ae020dec-69bf-478a-81f1-e387436066b6	d25787fb-aee2-4ff5-ad28-ce9c04a96300	comida_cocinada	28.17	2026-11-11	disponible	2026-09-27 11:58:10.709968+00
88d89179-b52e-4a19-924f-911e260a75b8	93b92c23-f2ec-4681-a17c-981cd343db64	donacion_corporativa	8.41	2026-10-04	disponible	2026-09-27 11:58:10.709968+00
f031b31b-adda-474a-9eab-892e42c83949	b9e72069-5fff-4637-be55-7af944773a18	campana_solidaria	29.69	2026-09-29	disponible	2026-09-27 11:58:10.709968+00
b40ad8df-8dc5-4c6c-9ad1-a44d937d1cbe	a5afd2f8-6fae-4b86-8166-7458c5baa1b8	comercio_local	2.96	2026-10-27	disponible	2026-09-27 11:58:10.709968+00
0e23aea5-2373-415e-8d66-b9c0d1f73125	ec93d5df-177b-41e2-b3e0-5ccbcbf5cce3	campana_solidaria	7.14	2026-11-11	disponible	2026-09-27 11:58:10.709968+00
444e1cbc-cbaf-47ee-9b0c-2b7f3d883015	e2fb1c66-65d1-4e91-b3c1-5000a15cc777	donacion_corporativa	3.67	2026-09-30	disponible	2026-09-27 11:58:10.709968+00
b1a29ffe-cc90-40df-a714-dafc45b3b545	5d90cee8-77c7-4353-bf48-8eeb999027a9	comida_cocinada	5.68	2026-11-26	disponible	2026-09-27 11:58:10.709968+00
43d5f5d4-313f-4e3b-835f-e16b271ae3bc	5d90cee8-77c7-4353-bf48-8eeb999027a9	campana_solidaria	24.19	2026-11-26	disponible	2026-09-27 11:58:10.709968+00
57ca9a92-1b0e-42da-b95d-e36046e46191	e2fb1c66-65d1-4e91-b3c1-5000a15cc777	comida_cocinada	26.64	2026-11-26	disponible	2026-09-27 11:58:10.709968+00
4207630d-4345-41ea-bb73-b40923406bc5	ec93d5df-177b-41e2-b3e0-5ccbcbf5cce3	excedente_agricola	37.45	2026-10-04	disponible	2026-09-27 11:58:10.709968+00
a20af7d2-d68c-408e-b157-eaba9b4ef0d2	a5afd2f8-6fae-4b86-8166-7458c5baa1b8	donacion_corporativa	11.36	2026-10-02	disponible	2026-09-27 11:58:10.709968+00
6f0bf690-791f-4020-a242-3b60a63c077b	d25787fb-aee2-4ff5-ad28-ce9c04a96300	comida_cocinada	13.33	2026-09-30	disponible	2026-09-27 11:58:10.709968+00
9cbcb2ad-e080-4046-bd4a-689daef3d71c	970b1df7-32e8-45d3-9d39-32f84b5bd476	comida_cocinada	25.23	2026-11-26	disponible	2026-09-27 11:58:10.709968+00
c92e268e-0bad-41ac-af3b-fb06ad1e53a6	5e490df4-0252-4fc1-8f1a-c287b63adda6	comercio_local	21.97	2026-11-11	disponible	2026-09-27 11:58:10.709968+00
f4690f4c-14e4-4792-9691-cbb03dd8af23	73de23c9-56b1-48b4-8072-6056ebf3d02a	donacion_corporativa	37.40	2026-09-30	disponible	2026-09-27 11:58:10.709968+00
cb93387d-f20e-4348-b214-28ac851bef09	5d90cee8-77c7-4353-bf48-8eeb999027a9	excedente_agricola	12.11	2026-10-27	disponible	2026-09-27 11:58:10.709968+00
6433e4e8-1e35-4a84-bff8-a525d5529f73	48615bef-c678-4b7d-a7bc-8d80b0a14ed7	excedente_agricola	24.86	2026-11-11	disponible	2026-09-27 11:58:10.709968+00
9b1915d2-a646-4778-aada-d880dd6787a0	970b1df7-32e8-45d3-9d39-32f84b5bd476	campana_solidaria	12.68	2026-09-30	disponible	2026-09-27 11:58:10.709968+00
7ea9c2ea-c7d3-410b-b2e0-06cf9bb18010	f0e267b9-1ccd-42a5-8013-f99b2c17fc35	excedente_agricola	5.50	2026-09-30	disponible	2026-09-27 11:58:10.709968+00
e699b423-7c47-4f53-ae00-d315ec20598b	48615bef-c678-4b7d-a7bc-8d80b0a14ed7	donacion_corporativa	11.62	2026-11-26	disponible	2026-09-27 11:58:10.709968+00
28911eb8-d9dd-44de-9e93-4ac4e18b3e1a	02bfb4c9-edc7-4342-872f-6e7cf2bf1185	excedente_agricola	8.94	2026-10-07	disponible	2026-09-27 11:58:10.709968+00
75fc0464-b30d-467b-8330-3dc89868fc14	ec93d5df-177b-41e2-b3e0-5ccbcbf5cce3	comida_cocinada	10.79	2026-09-29	disponible	2026-09-27 11:58:10.709968+00
67d3e8cd-cc51-41b3-b28b-535d50bc8bfc	e2fb1c66-65d1-4e91-b3c1-5000a15cc777	comida_cocinada	33.34	2026-09-29	disponible	2026-09-27 11:58:10.709968+00
0eae45d2-af73-4991-ae4d-244b5985cf19	970b1df7-32e8-45d3-9d39-32f84b5bd476	excedente_agricola	31.07	2026-10-07	disponible	2026-09-27 11:58:10.709968+00
3b7ecab6-b294-4d2c-81dc-6ae7fd1722eb	315fba23-0a03-40dd-b639-7b5ec70b9c0f	comida_cocinada	22.52	2026-10-17	disponible	2026-09-27 11:58:10.709968+00
3bb3f67d-efab-46e4-aa64-2c7450d28634	48615bef-c678-4b7d-a7bc-8d80b0a14ed7	comercio_local	5.36	2026-10-02	disponible	2026-09-27 11:58:10.709968+00
ffb819c0-f6cf-46a3-9209-35bcac862c77	48615bef-c678-4b7d-a7bc-8d80b0a14ed7	comercio_local	33.55	2026-11-26	disponible	2026-09-27 11:58:10.709968+00
c519b25a-09d4-471c-982c-c95296a1b64a	48615bef-c678-4b7d-a7bc-8d80b0a14ed7	donacion_corporativa	17.76	2026-09-29	disponible	2026-09-27 11:58:10.709968+00
51202691-d55a-4050-bf44-1928dc6d1ab0	d25787fb-aee2-4ff5-ad28-ce9c04a96300	excedente_agricola	36.06	2026-09-29	disponible	2026-09-27 11:58:10.709968+00
b254784c-a2c7-42d1-ba66-36e09379214f	12569c23-6848-40c7-a210-320d1042706f	donacion_corporativa	27.60	2026-09-30	disponible	2026-09-27 11:58:10.709968+00
47416706-1e11-4751-ab3f-5451639e314b	12569c23-6848-40c7-a210-320d1042706f	campana_solidaria	35.48	2026-10-17	disponible	2026-09-27 11:58:10.709968+00
4fc0ee8d-7bce-4ec2-9e76-7d6fd7b3046e	bb033dce-3da9-4fc3-a9c5-cd336326d0dd	donacion_corporativa	37.10	2026-10-04	disponible	2026-09-27 11:58:10.709968+00
e00b5dec-a2a2-4159-a2cc-94775eb4672c	315fba23-0a03-40dd-b639-7b5ec70b9c0f	donacion_corporativa	35.38	2026-09-29	disponible	2026-09-27 11:58:10.709968+00
\.


--
-- Data for Name: deliveries; Type: TABLE DATA; Schema: public; Owner: xama_user
--

COPY public.deliveries (id, family_id, delivery_date, site, volunteer_id, status, notes, checked_in_at, created_at) FROM stdin;
bf4cc232-b8c3-49de-9f2c-9cc6b832cd8b	237deca6-c4a7-46d5-b1f0-7db40f98cc5a	2026-09-27	tarragona	\N	entregada	\N	2026-09-27 11:58:10.745509+00	2026-09-27 11:58:10.743782+00
212137f0-5d81-4cbb-87e5-c6cffcdd9ee5	3df514e0-7f61-4d6b-849b-b59e96faa7c5	2026-09-27	reus	\N	entregada	\N	2026-09-27 11:58:10.745603+00	2026-09-27 11:58:10.743782+00
40780440-a7a4-451a-9db6-5357eeb08f25	8f1c892b-2a77-4281-9374-ba779d2cdc64	2026-09-27	tarragona	\N	entregada	\N	2026-09-27 11:58:10.745641+00	2026-09-27 11:58:10.743782+00
fe62e8ea-2f80-4d07-925f-9f79017c2d83	8f3a0945-5daf-423c-afce-0ff9e0d78e6d	2026-09-27	tarragona	\N	pendiente	\N	\N	2026-09-27 11:58:10.743782+00
883f119c-24d7-4a75-be3d-27f1ef7872c7	15ca2d15-81a2-4c27-9a7f-c43681fa55d6	2026-09-27	reus	\N	pendiente	\N	\N	2026-09-27 11:58:10.743782+00
2e2838ba-7467-41a8-b962-75777ebbbdc2	73217991-efda-49c2-bae4-cc08841b3a3a	2026-09-27	tarragona	\N	entregada	\N	2026-09-27 11:58:10.745725+00	2026-09-27 11:58:10.743782+00
150e6013-327b-4d02-93dc-61e8714631b3	3df514e0-7f61-4d6b-849b-b59e96faa7c5	2026-09-26	reus	\N	entregada	\N	2026-09-27 11:58:10.745766+00	2026-09-27 11:58:10.743782+00
75c76af8-9230-4df8-b3eb-858697331dac	68f2f335-0fbb-4dab-83ed-40a5b78cd396	2026-09-26	reus	\N	entregada	\N	2026-09-27 11:58:10.745793+00	2026-09-27 11:58:10.743782+00
65fef5e7-ca86-4699-8360-22456b5dda86	dc34de9d-c299-4f03-84da-78862c04e2d1	2026-09-26	tarragona	\N	entregada	\N	2026-09-27 11:58:10.745818+00	2026-09-27 11:58:10.743782+00
0daff046-fe62-431f-8b4f-a29b4f781ab0	eeda49bd-eb4c-4cf1-a8fe-124afb0d6e97	2026-09-26	tarragona	\N	entregada	\N	2026-09-27 11:58:10.745842+00	2026-09-27 11:58:10.743782+00
d31770ee-12ca-426d-b748-6d4b75967164	0c7f52aa-d8f6-4ecd-8af1-d0e0b9520591	2026-09-25	tarragona	\N	entregada	\N	2026-09-27 11:58:10.745878+00	2026-09-27 11:58:10.743782+00
95c5af20-3b23-4b21-b8fa-06720b94edfb	ddd4b67f-d95f-4285-afad-894745d6733d	2026-09-25	reus	\N	entregada	\N	2026-09-27 11:58:10.745905+00	2026-09-27 11:58:10.743782+00
d7a8de71-4068-4f63-a56e-7a83da1aa5c9	8f3a0945-5daf-423c-afce-0ff9e0d78e6d	2026-09-25	tarragona	\N	entregada	\N	2026-09-27 11:58:10.74593+00	2026-09-27 11:58:10.743782+00
f3fef992-ba1c-403b-8966-357b851a3e7a	f3edb054-8add-4c3e-95af-c45dab64f7e5	2026-09-25	reus	\N	entregada	\N	2026-09-27 11:58:10.745955+00	2026-09-27 11:58:10.743782+00
e0772abe-d225-4b79-9936-fe64936e7f7e	5144a43d-4a4f-40ad-b00e-9a9f6575f51e	2026-09-25	reus	\N	entregada	\N	2026-09-27 11:58:10.746002+00	2026-09-27 11:58:10.743782+00
77e6de22-f962-4440-9850-102844b2d505	12b2d21c-8397-4802-b2b9-319ca66f8a6a	2026-09-25	tarragona	\N	entregada	\N	2026-09-27 11:58:10.746028+00	2026-09-27 11:58:10.743782+00
f4503685-709e-4aaa-b84d-7e5af0ca3f99	73217991-efda-49c2-bae4-cc08841b3a3a	2026-09-25	tarragona	\N	entregada	\N	2026-09-27 11:58:10.746052+00	2026-09-27 11:58:10.743782+00
46391fab-6dab-4b58-bfb7-b9ea8e929331	e817b56a-1bdd-4e33-b5cd-15322e8cb595	2026-09-24	tarragona	\N	entregada	\N	2026-09-27 11:58:10.746088+00	2026-09-27 11:58:10.743782+00
e515b4de-743d-4f22-9afa-78de34f2c18c	3df514e0-7f61-4d6b-849b-b59e96faa7c5	2026-09-24	reus	\N	entregada	\N	2026-09-27 11:58:10.746115+00	2026-09-27 11:58:10.743782+00
e3eba6d3-8d9b-4303-9651-dfeb0045b3b2	e5e1abd1-4e54-48d6-ab4f-ac01f0aa3864	2026-09-24	tarragona	\N	entregada	\N	2026-09-27 11:58:10.746142+00	2026-09-27 11:58:10.743782+00
d0499288-c655-4000-8c47-fa64a252c39a	dc34de9d-c299-4f03-84da-78862c04e2d1	2026-09-24	tarragona	\N	entregada	\N	2026-09-27 11:58:10.746174+00	2026-09-27 11:58:10.743782+00
65fc20ef-970d-4d2b-8b3b-12eb95511295	1324968b-bcf7-444e-9cd8-b9a5d0153fe6	2026-09-23	reus	\N	entregada	\N	2026-09-27 11:58:10.746223+00	2026-09-27 11:58:10.743782+00
00af1731-cc4b-4679-9268-8fca1114f3bc	2b709a37-a1f5-4151-afc9-cf275fdec6c2	2026-09-23	tarragona	\N	entregada	\N	2026-09-27 11:58:10.746276+00	2026-09-27 11:58:10.743782+00
8383f556-4a85-48ef-965c-0a364487543d	15ca2d15-81a2-4c27-9a7f-c43681fa55d6	2026-09-23	reus	\N	entregada	\N	2026-09-27 11:58:10.746339+00	2026-09-27 11:58:10.743782+00
f0fd26c9-0830-4fc2-98cc-8fa9d8c7e818	5144a43d-4a4f-40ad-b00e-9a9f6575f51e	2026-09-23	reus	\N	entregada	\N	2026-09-27 11:58:10.746371+00	2026-09-27 11:58:10.743782+00
58f20d86-cd1f-4eea-9690-aa594dcbe0c8	f3edb054-8add-4c3e-95af-c45dab64f7e5	2026-09-22	reus	\N	entregada	\N	2026-09-27 11:58:10.746418+00	2026-09-27 11:58:10.743782+00
db5fc50d-7942-45a8-a9e9-dff565088bdf	ddd4b67f-d95f-4285-afad-894745d6733d	2026-09-22	reus	\N	entregada	\N	2026-09-27 11:58:10.74645+00	2026-09-27 11:58:10.743782+00
0b879b38-2978-4bd1-a4cf-d40a33058b69	c2f7667a-dd51-45fa-89f2-addc106de68e	2026-09-22	reus	\N	entregada	\N	2026-09-27 11:58:10.746478+00	2026-09-27 11:58:10.743782+00
57c787b8-e6d3-45e3-b253-6c2d91f0c600	28a8b5e1-a9fd-4cef-8297-0cdb97d167fa	2026-09-22	reus	\N	entregada	\N	2026-09-27 11:58:10.746509+00	2026-09-27 11:58:10.743782+00
56c6d607-1e68-4649-a431-5026d8d60235	3df514e0-7f61-4d6b-849b-b59e96faa7c5	2026-09-22	reus	\N	entregada	\N	2026-09-27 11:58:10.746537+00	2026-09-27 11:58:10.743782+00
69c8ec05-b392-4762-94ea-e48e50974f74	68f2f335-0fbb-4dab-83ed-40a5b78cd396	2026-09-22	reus	\N	entregada	\N	2026-09-27 11:58:10.746563+00	2026-09-27 11:58:10.743782+00
e0328f4f-03a5-44bc-91c8-291493d31525	d7cf0aa4-b5f9-43fe-9c0c-9ccd3231524d	2026-09-22	reus	\N	entregada	\N	2026-09-27 11:58:10.746592+00	2026-09-27 11:58:10.743782+00
cdf6efa9-f6e0-4ff2-8f50-9383b4118e51	e817b56a-1bdd-4e33-b5cd-15322e8cb595	2026-09-22	tarragona	\N	entregada	\N	2026-09-27 11:58:10.74662+00	2026-09-27 11:58:10.743782+00
dada7df0-6358-4298-808e-06f168c978bb	237deca6-c4a7-46d5-b1f0-7db40f98cc5a	2026-09-22	tarragona	\N	entregada	\N	2026-09-27 11:58:10.746651+00	2026-09-27 11:58:10.743782+00
40756de6-0dbf-4ed0-976a-fd68764852e0	dc34de9d-c299-4f03-84da-78862c04e2d1	2026-09-22	tarragona	\N	entregada	\N	2026-09-27 11:58:10.746683+00	2026-09-27 11:58:10.743782+00
f1d2b1ed-6b13-4692-9b35-13ad4731e6ba	cb6136b1-414b-4efd-8955-e44ae55114f9	2026-09-21	tarragona	\N	entregada	\N	2026-09-27 11:58:10.746734+00	2026-09-27 11:58:10.743782+00
6e4e6d9f-140e-4358-9b76-82fa6aa37e73	3df514e0-7f61-4d6b-849b-b59e96faa7c5	2026-09-21	reus	\N	entregada	\N	2026-09-27 11:58:10.746771+00	2026-09-27 11:58:10.743782+00
1d45708f-a4eb-4249-b308-7d41be387fe9	28a8b5e1-a9fd-4cef-8297-0cdb97d167fa	2026-09-21	reus	\N	entregada	\N	2026-09-27 11:58:10.746801+00	2026-09-27 11:58:10.743782+00
7534e527-31e6-4eb8-8453-10a261f48c65	237deca6-c4a7-46d5-b1f0-7db40f98cc5a	2026-09-21	tarragona	\N	entregada	\N	2026-09-27 11:58:10.74683+00	2026-09-27 11:58:10.743782+00
f0033a30-ad05-446d-85f7-43702e906eed	15ca2d15-81a2-4c27-9a7f-c43681fa55d6	2026-09-21	reus	\N	entregada	\N	2026-09-27 11:58:10.746858+00	2026-09-27 11:58:10.743782+00
dce01281-ab29-4d08-98e6-7364b63d8085	8f1c892b-2a77-4281-9374-ba779d2cdc64	2026-09-21	tarragona	\N	entregada	\N	2026-09-27 11:58:10.746901+00	2026-09-27 11:58:10.743782+00
6ca7a29c-7af5-4098-b40a-9c19f766de00	1324968b-bcf7-444e-9cd8-b9a5d0153fe6	2026-09-21	reus	\N	entregada	\N	2026-09-27 11:58:10.74693+00	2026-09-27 11:58:10.743782+00
9244385c-2d1e-4f87-af51-2eb57fa5ed48	ff78a2c8-3a0b-490e-8525-0db0b15f4c43	2026-09-21	tarragona	\N	entregada	\N	2026-09-27 11:58:10.746957+00	2026-09-27 11:58:10.743782+00
79159aac-a1e5-41de-93f8-3b15f75cb9e3	4b2e8f9e-fdf6-4829-88c6-b8f052b46984	2026-09-21	reus	\N	entregada	\N	2026-09-27 11:58:10.746984+00	2026-09-27 11:58:10.743782+00
65e558c4-88f8-4f69-ad8e-2139e69aa0e9	73217991-efda-49c2-bae4-cc08841b3a3a	2026-09-21	tarragona	\N	entregada	\N	2026-09-27 11:58:10.747008+00	2026-09-27 11:58:10.743782+00
\.


--
-- Data for Name: derivations; Type: TABLE DATA; Schema: public; Owner: xama_user
--

COPY public.derivations (id, reference_code, person_name, origin, reason, rations, status, served_at, notes, created_at) FROM stdin;
06b0c7ee-c1ae-4459-969d-7d3ffb7087ec	DER-200	Pablo Díaz	policia_local	Persona sin hogar	1	servida	2026-09-27 11:58:10.775705+00	\N	2026-09-27 11:58:10.773796+00
90a7077a-0f75-4dcf-985d-69c84c4a6bde	DER-201	\N	cruz_roja	Persona sin hogar	4	servida	2026-09-27 11:58:10.775825+00	\N	2026-09-27 11:58:10.773796+00
750071c4-663d-4390-a11b-71a69241a061	DER-202	\N	servicios_sociales	Persona sin hogar	3	servida	2026-09-27 11:58:10.77592+00	\N	2026-09-27 11:58:10.773796+00
047b91f2-789d-4973-a91d-055e842d8310	DER-203	Patricia Martínez	voluntario	Persona sin hogar	3	pendiente	\N	\N	2026-09-27 11:58:10.773796+00
c7af37e6-5d09-4d0b-b9af-93b61e0da371	DER-204	\N	voluntario	Persona sin hogar	4	pendiente	\N	\N	2026-09-27 11:58:10.773796+00
76f1ac90-0d8f-44c5-b9ef-039274f47515	DER-205	Antonio Ramos	policia_local	Persona sin hogar	4	pendiente	\N	\N	2026-09-27 11:58:10.773796+00
d3837401-3bb2-4cc2-bac9-f3dfe42be8a4	DER-206	Nuria Díaz	voluntario	Persona sin hogar	4	servida	2026-09-27 11:58:10.776211+00	\N	2026-09-27 11:58:10.773796+00
b6a8106f-1145-4409-9d79-2bc1cdc6e589	DER-207	\N	cruz_roja	Persona sin hogar	4	servida	2026-09-27 11:58:10.776284+00	\N	2026-09-27 11:58:10.773796+00
80b04563-a609-492c-b08d-8f856d695607	DER-208	Pablo Moreno	servicios_sociales	Persona sin hogar	4	servida	2026-09-27 11:58:10.776352+00	\N	2026-09-27 11:58:10.773796+00
7fe8ede2-29ee-4aff-be12-a686bd662dd9	DER-209	\N	cruz_roja	Persona sin hogar	3	servida	2026-09-27 11:58:10.776389+00	\N	2026-09-27 11:58:10.773796+00
\.


--
-- Data for Name: families; Type: TABLE DATA; Schema: public; Owner: xama_user
--

COPY public.families (id, reference_code, address, phone, adults, minors, dietary_restrictions, notes, site, active, created_at) FROM stdin;
4b2e8f9e-fdf6-4829-88c6-b8f052b46984	FAM-100	Carrer de Sant Joan 86, reus	665259205	2	2	\N	\N	reus	t	2026-09-27 11:58:10.727982+00
c2f7667a-dd51-45fa-89f2-addc106de68e	FAM-101	Avinguda de Roma 98, reus	615197528	4	1	\N	\N	reus	t	2026-09-27 11:58:10.727982+00
1324968b-bcf7-444e-9cd8-b9a5d0153fe6	FAM-102	Carrer de la Pau 90, reus	650962024	2	1	\N	\N	reus	t	2026-09-27 11:58:10.727982+00
69c61d49-39f1-47ff-bad9-fd7d2272d1aa	FAM-103	Rambla Nova 103, reus	654058573	3	0	\N	\N	reus	t	2026-09-27 11:58:10.727982+00
5144a43d-4a4f-40ad-b00e-9a9f6575f51e	FAM-104	Plaça Prim 131, reus	663643924	3	0	\N	\N	reus	t	2026-09-27 11:58:10.727982+00
ddd4b67f-d95f-4285-afad-894745d6733d	FAM-105	Carrer de l'Estació 46, reus	687925434	3	0	\N	\N	reus	t	2026-09-27 11:58:10.727982+00
d7cf0aa4-b5f9-43fe-9c0c-9ccd3231524d	FAM-106	Carrer Ample 89, reus	652101056	4	4	Sin lactosa	\N	reus	t	2026-09-27 11:58:10.727982+00
37fd5ec3-7e03-453c-a922-3ef2201c431e	FAM-107	Avinguda de Roma 99, reus	687388337	2	2	\N	\N	reus	t	2026-09-27 11:58:10.727982+00
28a8b5e1-a9fd-4cef-8297-0cdb97d167fa	FAM-108	Carrer Ample 1, reus	679782527	2	2	Sin gluten	\N	reus	t	2026-09-27 11:58:10.727982+00
b0b31143-09eb-4f79-bb5b-137437041fbc	FAM-109	Avinguda de Roma 85, reus	693638503	3	0	Vegetariana	\N	reus	t	2026-09-27 11:58:10.727982+00
68f2f335-0fbb-4dab-83ed-40a5b78cd396	FAM-110	Carrer de l'Estació 130, reus	651511484	4	2	Sin gluten	\N	reus	t	2026-09-27 11:58:10.727982+00
10325fa3-3630-4a94-ba08-de3b71d48d38	FAM-111	Carrer de l'Estació 142, reus	627084279	2	3	Vegetariana	\N	reus	t	2026-09-27 11:58:10.727982+00
3df514e0-7f61-4d6b-849b-b59e96faa7c5	FAM-112	Carrer Ample 45, reus	692613013	3	3	Sin lactosa	\N	reus	t	2026-09-27 11:58:10.727982+00
15ca2d15-81a2-4c27-9a7f-c43681fa55d6	FAM-113	Carrer Major 78, reus	648508907	2	3	Sin lactosa	\N	reus	t	2026-09-27 11:58:10.727982+00
f3edb054-8add-4c3e-95af-c45dab64f7e5	FAM-114	Plaça Prim 120, reus	669295515	4	1	Sin lactosa	\N	reus	t	2026-09-27 11:58:10.727982+00
ff78a2c8-3a0b-490e-8525-0db0b15f4c43	FAM-115	Carrer de la Pau 44, tarragona	698429450	1	2	Sin lactosa	\N	tarragona	t	2026-09-27 11:58:10.727982+00
8763cb4a-3c33-4f11-8ca1-1199497ae371	FAM-116	Plaça Prim 24, tarragona	641523529	3	1	\N	\N	tarragona	t	2026-09-27 11:58:10.727982+00
73217991-efda-49c2-bae4-cc08841b3a3a	FAM-117	Carrer de Sant Joan 7, tarragona	616202700	2	3	Sin lactosa	\N	tarragona	t	2026-09-27 11:58:10.727982+00
e5e1abd1-4e54-48d6-ab4f-ac01f0aa3864	FAM-118	Avinguda de Roma 117, tarragona	665625330	2	3	Sin gluten	\N	tarragona	t	2026-09-27 11:58:10.727982+00
12b2d21c-8397-4802-b2b9-319ca66f8a6a	FAM-119	Carrer Ample 63, tarragona	629806690	1	0	Sin gluten	\N	tarragona	t	2026-09-27 11:58:10.727982+00
2b709a37-a1f5-4151-afc9-cf275fdec6c2	FAM-120	Rambla Nova 46, tarragona	679519112	4	0	Sin lactosa	\N	tarragona	t	2026-09-27 11:58:10.727982+00
dc34de9d-c299-4f03-84da-78862c04e2d1	FAM-121	Rambla Nova 32, tarragona	671265269	2	3	Vegetariana	\N	tarragona	t	2026-09-27 11:58:10.727982+00
2b6f5752-246d-49cf-8ffd-a2a69d1a26c0	FAM-122	Plaça Prim 114, tarragona	692228802	4	4	Sin gluten	\N	tarragona	t	2026-09-27 11:58:10.727982+00
0c7f52aa-d8f6-4ecd-8af1-d0e0b9520591	FAM-123	Carrer de Sant Joan 122, tarragona	670407340	3	1	Vegetariana	\N	tarragona	t	2026-09-27 11:58:10.727982+00
237deca6-c4a7-46d5-b1f0-7db40f98cc5a	FAM-124	Carrer de l'Estació 134, tarragona	675041510	2	2	Sin gluten	\N	tarragona	t	2026-09-27 11:58:10.727982+00
eeda49bd-eb4c-4cf1-a8fe-124afb0d6e97	FAM-125	Avinguda de Roma 74, tarragona	641473195	3	2	\N	\N	tarragona	t	2026-09-27 11:58:10.727982+00
8f3a0945-5daf-423c-afce-0ff9e0d78e6d	FAM-126	Avinguda de Roma 36, tarragona	630244148	2	3	Vegetariana	\N	tarragona	t	2026-09-27 11:58:10.727982+00
8f1c892b-2a77-4281-9374-ba779d2cdc64	FAM-127	Carrer de Sant Joan 55, tarragona	618620650	4	3	\N	\N	tarragona	t	2026-09-27 11:58:10.727982+00
cb6136b1-414b-4efd-8955-e44ae55114f9	FAM-128	Carrer de la Pau 107, tarragona	618357162	2	3	Sin gluten	\N	tarragona	t	2026-09-27 11:58:10.727982+00
e817b56a-1bdd-4e33-b5cd-15322e8cb595	FAM-129	Carrer Major 148, tarragona	661053877	4	0	\N	\N	tarragona	t	2026-09-27 11:58:10.727982+00
\.


--
-- Data for Name: nevera_rations; Type: TABLE DATA; Schema: public; Owner: xama_user
--

COPY public.nevera_rations (id, date, target_rations, served_rations, notes, created_at) FROM stdin;
a2bd3527-dcb7-4a1c-ade3-1fe33c839370	2026-09-27	20	14	\N	2026-09-27 11:58:10.762268+00
9fafc069-662f-48c3-b2f8-190a9a7a16bd	2026-09-26	20	19	\N	2026-09-27 11:58:10.762268+00
7a843c12-93b6-42f5-a1c5-ef76e96ff659	2026-09-25	20	17	\N	2026-09-27 11:58:10.762268+00
1ffab749-433a-4eed-b7d7-d3a4415dba57	2026-09-24	20	15	\N	2026-09-27 11:58:10.762268+00
d4b1bcf5-2301-45f5-8d2c-fd24562251bf	2026-09-23	20	14	\N	2026-09-27 11:58:10.762268+00
904a0353-8c96-481f-a1e4-6571b0411721	2026-09-22	20	14	\N	2026-09-27 11:58:10.762268+00
6151a8e8-b894-4e45-a22c-8fdf02cff5ce	2026-09-21	20	17	\N	2026-09-27 11:58:10.762268+00
2ccedfd6-4114-46cd-8317-489a7f1bd9a2	2026-09-20	20	17	\N	2026-09-27 11:58:10.762268+00
4c5b3408-e752-47ab-bc19-4ae87aeef1d0	2026-09-19	20	14	\N	2026-09-27 11:58:10.762268+00
47fc5ae9-0d57-459d-a32d-f838cdf13c2f	2026-09-18	20	16	\N	2026-09-27 11:58:10.762268+00
747b29fe-7011-4e54-9656-2127e4f4032a	2026-09-17	20	17	\N	2026-09-27 11:58:10.762268+00
6ee8f35f-4183-45e1-8998-3fdb4482b7cb	2026-09-16	20	16	\N	2026-09-27 11:58:10.762268+00
46c2a692-7dff-4a41-9269-e6949a39f758	2026-09-15	20	21	\N	2026-09-27 11:58:10.762268+00
c6b32892-fc23-437b-a7ac-a0b37343e763	2026-09-14	20	15	\N	2026-09-27 11:58:10.762268+00
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: xama_user
--

COPY public.products (id, name, category, unit, created_at) FROM stdin;
970b1df7-32e8-45d3-9d39-32f84b5bd476	Manzanas	fruta	kg	2026-09-27 11:58:10.69118+00
b9e72069-5fff-4637-be55-7af944773a18	Plátanos	fruta	kg	2026-09-27 11:58:10.69118+00
e2fb1c66-65d1-4e91-b3c1-5000a15cc777	Naranjas	fruta	kg	2026-09-27 11:58:10.69118+00
5e490df4-0252-4fc1-8f1a-c287b63adda6	Tomates	verdura	kg	2026-09-27 11:58:10.69118+00
f0e267b9-1ccd-42a5-8013-f99b2c17fc35	Lechuga	verdura	unidad	2026-09-27 11:58:10.69118+00
315fba23-0a03-40dd-b639-7b5ec70b9c0f	Zanahorias	verdura	kg	2026-09-27 11:58:10.69118+00
02bfb4c9-edc7-4342-872f-6e7cf2bf1185	Patatas	verdura	kg	2026-09-27 11:58:10.69118+00
5d90cee8-77c7-4353-bf48-8eeb999027a9	Cebollas	verdura	kg	2026-09-27 11:58:10.69118+00
73de23c9-56b1-48b4-8072-6056ebf3d02a	Pan de molde	panaderia	unidad	2026-09-27 11:58:10.69118+00
d25787fb-aee2-4ff5-ad28-ce9c04a96300	Baguettes	panaderia	unidad	2026-09-27 11:58:10.69118+00
a5afd2f8-6fae-4b86-8166-7458c5baa1b8	Croissants	bolleria	unidad	2026-09-27 11:58:10.69118+00
12569c23-6848-40c7-a210-320d1042706f	Leche entera	lacteos	litro	2026-09-27 11:58:10.69118+00
6af072c3-3ec0-44d7-9935-144a4ee9550c	Yogur natural	lacteos	unidad	2026-09-27 11:58:10.69118+00
9db83ff6-78d3-463c-83a0-26c406715fa3	Queso tierno	lacteos	kg	2026-09-27 11:58:10.69118+00
0fd996a9-a697-4cdf-b715-4f97931e8df0	Arroz	granos	kg	2026-09-27 11:58:10.69118+00
93b92c23-f2ec-4681-a17c-981cd343db64	Pasta	granos	kg	2026-09-27 11:58:10.69118+00
ec93d5df-177b-41e2-b3e0-5ccbcbf5cce3	Lentejas	legumbres	kg	2026-09-27 11:58:10.69118+00
48615bef-c678-4b7d-a7bc-8d80b0a14ed7	Garbanzos	legumbres	kg	2026-09-27 11:58:10.69118+00
f76b0aff-8aa7-4a71-bf32-47c5d2c3c02e	Atún en lata	conservas	unidad	2026-09-27 11:58:10.69118+00
bb033dce-3da9-4fc3-a9c5-cd336326d0dd	Aceite de oliva	aceites	litro	2026-09-27 11:58:10.69118+00
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: xama_user
--

COPY public.roles (id, name) FROM stdin;
1	junta
2	coordinador_reus
3	coordinador_tarragona
4	voluntario
5	servicios_sociales
\.


--
-- Data for Name: shift_assignments; Type: TABLE DATA; Schema: public; Owner: xama_user
--

COPY public.shift_assignments (id, shift_id, user_id, hours, attended, notes, created_at) FROM stdin;
d9c99e9e-70d0-462f-8e2e-3b327b54c323	6ca9b406-1d82-4ac7-b8fe-21599ca3c583	296d2a32-284c-465c-9b7a-ac720cbaada6	\N	t	\N	2026-09-27 11:58:10.811745+00
e8f4be3c-c7a3-4a53-9590-56be8717c922	89fb87a0-66a8-431c-a30a-2a84bafa57bb	ec476a00-2ab3-4eb9-9a23-e060d3855c20	\N	f	\N	2026-09-27 11:58:10.811745+00
e2760933-3eed-4cfd-abf1-4bf589440265	89fb87a0-66a8-431c-a30a-2a84bafa57bb	ebea5cfd-bb12-4dc6-856c-60b403001057	\N	f	\N	2026-09-27 11:58:10.811745+00
8bbe9d9f-753d-41e2-9c85-3cc61c5518aa	7b4fed7f-5091-4d9a-b6fc-17130bd8a347	66da7d9e-3341-4b65-92a1-247e2d7d4682	3.40	f	\N	2026-09-27 11:58:10.811745+00
c2f17597-a451-490f-a50c-8301c61fffd7	7b4fed7f-5091-4d9a-b6fc-17130bd8a347	26e335c0-a201-4a5c-ae10-e2792a17c806	3.00	t	\N	2026-09-27 11:58:10.811745+00
77c4eb3c-3c7d-4b69-bffb-d242366cd2b1	7b4fed7f-5091-4d9a-b6fc-17130bd8a347	c0894749-def7-4bb8-9714-fdc1d61cbc3d	2.90	t	\N	2026-09-27 11:58:10.811745+00
5fd14e00-3db3-4033-8a09-0f4a927c1823	7b4fed7f-5091-4d9a-b6fc-17130bd8a347	ebea5cfd-bb12-4dc6-856c-60b403001057	\N	f	\N	2026-09-27 11:58:10.811745+00
37499dd2-a5f2-4c21-b4f1-355aba031706	73a96d0d-db19-4b88-b126-192ac4a1ff8f	ec476a00-2ab3-4eb9-9a23-e060d3855c20	\N	f	\N	2026-09-27 11:58:10.811745+00
a693dc98-2ca5-48f9-bf6c-d4c691c1b98b	73a96d0d-db19-4b88-b126-192ac4a1ff8f	ebea5cfd-bb12-4dc6-856c-60b403001057	2.10	f	\N	2026-09-27 11:58:10.811745+00
28c1ddfa-e999-4a21-8966-800a666e098d	73a96d0d-db19-4b88-b126-192ac4a1ff8f	13e0ec78-5c85-4202-af14-c51288fa9b7d	2.60	t	\N	2026-09-27 11:58:10.811745+00
c39dfc5f-3f27-4d90-8668-66df5f5dc461	7178f823-f539-4e70-aef6-0ece48a52f20	9dd2749b-3951-47f9-80ee-be50cf283f42	2.50	t	\N	2026-09-27 11:58:10.811745+00
1030b3b7-bfea-4427-8fd9-82a52e35d713	7178f823-f539-4e70-aef6-0ece48a52f20	3eb35f4e-2dde-4b9d-8103-1012d06f82c1	\N	t	\N	2026-09-27 11:58:10.811745+00
d4c0642f-cf48-43f6-838c-47c761f175f0	7178f823-f539-4e70-aef6-0ece48a52f20	cb17a8ef-3807-4d9a-a2bd-5c735c7b06a8	4.00	f	\N	2026-09-27 11:58:10.811745+00
afdd4743-129c-4fea-8ec8-5e72caffa492	7178f823-f539-4e70-aef6-0ece48a52f20	54038861-05e1-4131-91eb-e8ca032457ce	3.20	t	\N	2026-09-27 11:58:10.811745+00
b2e3d9a2-4e4d-4b9f-972a-2082eebf6e8f	1ea57f26-35fc-4376-b1d6-0852c4d5cbe0	34721c74-d837-4355-850d-85d7a3fc15aa	2.30	f	\N	2026-09-27 11:58:10.811745+00
4d00f993-740e-45a0-9903-3ae6afe3e085	f32d39da-caed-4469-8bc3-14ad43c320c0	045f636b-55dd-4fc9-b216-34cbe41545ca	\N	f	\N	2026-09-27 11:58:10.811745+00
cdebf5fd-2e3e-454a-961c-2063647f9cc3	f32d39da-caed-4469-8bc3-14ad43c320c0	b1701ae8-c9a0-49b9-abaa-0270d36aeb65	\N	f	\N	2026-09-27 11:58:10.811745+00
ffcb7072-0a03-4ec7-84fc-6efefe5e2f93	f32d39da-caed-4469-8bc3-14ad43c320c0	f746a983-c8c3-4586-a091-a2a36c91496f	2.10	f	\N	2026-09-27 11:58:10.811745+00
c70acb8a-546f-4710-8ab1-9e70a741ef69	4015d9f8-48b7-4ecf-92cb-faf11d0405c7	9dd2749b-3951-47f9-80ee-be50cf283f42	3.30	t	\N	2026-09-27 11:58:10.811745+00
30c28db0-5868-4e3f-b936-0903119b45ad	4015d9f8-48b7-4ecf-92cb-faf11d0405c7	54038861-05e1-4131-91eb-e8ca032457ce	\N	t	\N	2026-09-27 11:58:10.811745+00
44deb5b2-3eb1-4c20-9a08-a3bf4ef6fac5	ad5472d1-23a7-4fff-864c-769bfbacee27	54038861-05e1-4131-91eb-e8ca032457ce	\N	f	\N	2026-09-27 11:58:10.811745+00
82e25816-d22a-481f-82a7-50d9f4d6b53e	c29a7b3b-e907-408f-823d-23887fde6a9d	f746a983-c8c3-4586-a091-a2a36c91496f	\N	t	\N	2026-09-27 11:58:10.811745+00
e9601a63-d231-46de-b127-e1d58dd30922	c29a7b3b-e907-408f-823d-23887fde6a9d	67d7802c-2658-418a-bb33-4873fdc63992	3.90	t	\N	2026-09-27 11:58:10.811745+00
442ba589-c7c8-4285-b763-4b4ca193ac45	f885b9bb-0743-441d-b387-7c7faf9b6f09	045f636b-55dd-4fc9-b216-34cbe41545ca	\N	t	\N	2026-09-27 11:58:10.811745+00
67f98340-9a5b-4d18-946a-e2e4a2896fc4	f885b9bb-0743-441d-b387-7c7faf9b6f09	13e0ec78-5c85-4202-af14-c51288fa9b7d	\N	f	\N	2026-09-27 11:58:10.811745+00
12bcf5aa-a320-477f-bc6c-346fa0a0891e	f885b9bb-0743-441d-b387-7c7faf9b6f09	f746a983-c8c3-4586-a091-a2a36c91496f	\N	t	\N	2026-09-27 11:58:10.811745+00
9d8dff8a-bc58-4573-a27e-9d5dce35ae0e	5f1fa009-afc6-4c78-96c2-ea0710a327ff	c0894749-def7-4bb8-9714-fdc1d61cbc3d	3.50	f	\N	2026-09-27 11:58:10.811745+00
a9a55db2-6642-45f9-8ee3-e91e85a5c8ae	5f1fa009-afc6-4c78-96c2-ea0710a327ff	48e414f6-e5eb-4b68-864d-43eceb9d2203	2.90	f	\N	2026-09-27 11:58:10.811745+00
d6db28fb-24d6-4ffc-a55e-c3adb1785126	5f1fa009-afc6-4c78-96c2-ea0710a327ff	a8d5f730-959a-42f8-b790-70cc4a3c80f0	2.90	t	\N	2026-09-27 11:58:10.811745+00
db986a5e-7eb2-4333-9e6e-e55773d6d654	5f1fa009-afc6-4c78-96c2-ea0710a327ff	66da7d9e-3341-4b65-92a1-247e2d7d4682	2.90	t	\N	2026-09-27 11:58:10.811745+00
38806d46-233d-41e2-b85a-be5c3ee6c147	fd5e6b98-bccc-4df3-aab6-83e156ad6e43	ec476a00-2ab3-4eb9-9a23-e060d3855c20	\N	t	\N	2026-09-27 11:58:10.811745+00
4d0532c8-13dd-491d-a605-bdf658a43d1f	fd5e6b98-bccc-4df3-aab6-83e156ad6e43	ebea5cfd-bb12-4dc6-856c-60b403001057	\N	t	\N	2026-09-27 11:58:10.811745+00
f5429a55-a8e8-4805-b674-8476beba8284	43bb0271-02fe-4303-994c-e36ec942335e	68ad1573-01cc-4d4e-ae39-c91c17eb062f	\N	f	\N	2026-09-27 11:58:10.811745+00
2dbc96a3-095d-462e-9543-15c48917c2aa	43bb0271-02fe-4303-994c-e36ec942335e	9dd2749b-3951-47f9-80ee-be50cf283f42	\N	f	\N	2026-09-27 11:58:10.811745+00
69d18537-61ae-4706-bc29-df902435e771	43bb0271-02fe-4303-994c-e36ec942335e	2b3825ad-a43c-4d75-b3d3-a34b2e04cbae	3.70	t	\N	2026-09-27 11:58:10.811745+00
0ff449ef-addc-433f-8f9d-04905ad382a8	80d3a98f-00e8-44d8-93dd-4c4e6935c8d6	68ad1573-01cc-4d4e-ae39-c91c17eb062f	\N	f	\N	2026-09-27 11:58:10.811745+00
9b2c66ff-02f2-41ab-b3c5-030f8b0cb76d	80d3a98f-00e8-44d8-93dd-4c4e6935c8d6	2b3825ad-a43c-4d75-b3d3-a34b2e04cbae	3.20	t	\N	2026-09-27 11:58:10.811745+00
ff6c3387-e89a-405e-b96d-fa85a7f59ddf	d66523e8-67aa-434e-a336-aa993636c546	9dd2749b-3951-47f9-80ee-be50cf283f42	\N	f	\N	2026-09-27 11:58:10.811745+00
1f38d70e-992c-4c62-9cca-1ca7b41587f7	fc999197-139c-477b-a78f-ddcc20b534c8	f746a983-c8c3-4586-a091-a2a36c91496f	\N	t	\N	2026-09-27 11:58:10.811745+00
02698df1-7685-4594-8d2c-0d25f7d0ba7f	24f50b41-98a0-44a5-a2bf-e8bcbac48a91	67d7802c-2658-418a-bb33-4873fdc63992	3.10	f	\N	2026-09-27 11:58:10.811745+00
8bb3472b-2092-4d90-b7a1-9b27e72feee4	24f50b41-98a0-44a5-a2bf-e8bcbac48a91	b1701ae8-c9a0-49b9-abaa-0270d36aeb65	3.80	t	\N	2026-09-27 11:58:10.811745+00
256c0c9e-39c7-4ea1-b0cc-37eaf07e84c0	24f50b41-98a0-44a5-a2bf-e8bcbac48a91	f5c04ce2-2768-4047-8026-12e940f96be1	\N	t	\N	2026-09-27 11:58:10.811745+00
b3b2e1a2-a8be-4bd2-8d80-2e3e9785604f	24f50b41-98a0-44a5-a2bf-e8bcbac48a91	66da7d9e-3341-4b65-92a1-247e2d7d4682	\N	t	\N	2026-09-27 11:58:10.811745+00
1dfbb0ed-a4ad-4154-8814-218515b85550	e7da82da-552a-452e-9ae4-7ed7e874a110	e2d92b3d-9023-4d2f-83f0-1b31cf1511a1	\N	t	\N	2026-09-27 11:58:10.811745+00
c9f42297-4324-4864-94e1-0dff1a7cd3e1	e7da82da-552a-452e-9ae4-7ed7e874a110	34721c74-d837-4355-850d-85d7a3fc15aa	\N	t	\N	2026-09-27 11:58:10.811745+00
3cdf7fe4-a81d-4630-850d-24fcee3bc652	5513d1b1-21f3-4f74-8cc1-459592a79f49	3eb35f4e-2dde-4b9d-8103-1012d06f82c1	\N	t	\N	2026-09-27 11:58:10.811745+00
fd8ac84b-e470-4b11-b844-dcef7d3c5df8	5c567893-982e-4eaa-b0c2-3d082351d642	68ad1573-01cc-4d4e-ae39-c91c17eb062f	\N	t	\N	2026-09-27 11:58:10.811745+00
2c3bd099-9eeb-49c7-90b8-564c355fe55c	52c112b1-58ea-46f9-86d8-965def76af56	6c5ae079-39f7-432b-a37b-e9743394f8ef	\N	f	\N	2026-09-27 11:58:10.811745+00
2837f855-1257-4756-93c9-e505e63ade18	52c112b1-58ea-46f9-86d8-965def76af56	9dd2749b-3951-47f9-80ee-be50cf283f42	3.70	t	\N	2026-09-27 11:58:10.811745+00
90d437b9-4a3f-45de-87ae-4a0b9a83531d	52c112b1-58ea-46f9-86d8-965def76af56	2b3825ad-a43c-4d75-b3d3-a34b2e04cbae	3.70	t	\N	2026-09-27 11:58:10.811745+00
1b372090-fb26-4e30-8a5e-979cc79d43ee	f9a0ef18-158c-45de-a521-0eb93d8d2a85	b1701ae8-c9a0-49b9-abaa-0270d36aeb65	2.80	t	\N	2026-09-27 11:58:10.811745+00
eb02ce47-888e-4118-b466-5f8c830a80ab	f9a0ef18-158c-45de-a521-0eb93d8d2a85	0c5065e8-f021-4b1b-99b8-e266270cf484	4.00	f	\N	2026-09-27 11:58:10.811745+00
d6603f53-b382-466a-b3c7-fb4eef49849d	f9a0ef18-158c-45de-a521-0eb93d8d2a85	2526cd20-7cd8-4784-9f72-6147701fe4d6	\N	t	\N	2026-09-27 11:58:10.811745+00
f50d99b0-2566-4218-bf64-65493b7ea3d6	577b58d5-fa4f-4503-98a9-60fb1caeb6e1	13e0ec78-5c85-4202-af14-c51288fa9b7d	\N	t	\N	2026-09-27 11:58:10.811745+00
97bc9e5f-2bf9-4290-a30f-3875183ccd4e	577b58d5-fa4f-4503-98a9-60fb1caeb6e1	0c5065e8-f021-4b1b-99b8-e266270cf484	\N	t	\N	2026-09-27 11:58:10.811745+00
5993575e-5c04-40bb-8c98-83d097d9e228	577b58d5-fa4f-4503-98a9-60fb1caeb6e1	b1701ae8-c9a0-49b9-abaa-0270d36aeb65	3.30	f	\N	2026-09-27 11:58:10.811745+00
f0f383a4-c990-4433-9b30-1bed0cdd1127	ca2a672c-cdfb-4ce3-8dd1-d64eeabe8a0d	a8d5f730-959a-42f8-b790-70cc4a3c80f0	3.70	t	\N	2026-09-27 11:58:10.811745+00
f3c0b045-1c6d-4ccc-beab-2e9a46a21253	0198e390-eeb4-4b59-854d-1b16e833cfeb	d4f37236-69cb-46a1-a60e-1e7d564ac014	\N	t	\N	2026-09-27 11:58:10.811745+00
29428834-0d5f-4456-a727-7bb53e02b29b	0198e390-eeb4-4b59-854d-1b16e833cfeb	e2d92b3d-9023-4d2f-83f0-1b31cf1511a1	\N	t	\N	2026-09-27 11:58:10.811745+00
c2b05cb4-06bb-4cad-80e5-2234e519048a	0198e390-eeb4-4b59-854d-1b16e833cfeb	6edf7518-f332-49f0-886d-c1c76af9e44a	2.70	t	\N	2026-09-27 11:58:10.811745+00
efd08935-c970-4e1c-a821-d8b619f0b051	30abe2f9-7cb0-470f-a1a4-cc9fe17202a1	68ad1573-01cc-4d4e-ae39-c91c17eb062f	2.80	f	\N	2026-09-27 11:58:10.811745+00
e683d254-4752-48f0-9b8e-5f819b0a4f61	30abe2f9-7cb0-470f-a1a4-cc9fe17202a1	b1c1c787-a63a-48ae-99d3-8a166cc80427	3.50	t	\N	2026-09-27 11:58:10.811745+00
36f6a907-42da-4f5a-b734-467ead6e7258	da51f134-3334-47af-b7fd-6fa6b5cc86f8	f746a983-c8c3-4586-a091-a2a36c91496f	3.50	t	\N	2026-09-27 11:58:10.811745+00
cbbe1273-7ece-4e9b-bb62-10d43521b8f0	f2b0f9d4-082a-4ad9-b6fb-3e14acdc144a	6edf7518-f332-49f0-886d-c1c76af9e44a	2.10	t	\N	2026-09-27 11:58:10.811745+00
12c07da0-a0f9-486f-82fd-4493315d9104	f2b0f9d4-082a-4ad9-b6fb-3e14acdc144a	e2d92b3d-9023-4d2f-83f0-1b31cf1511a1	\N	f	\N	2026-09-27 11:58:10.811745+00
66178e23-3b86-4756-9476-7e7105953671	f2b0f9d4-082a-4ad9-b6fb-3e14acdc144a	34721c74-d837-4355-850d-85d7a3fc15aa	\N	t	\N	2026-09-27 11:58:10.811745+00
b33dec44-06dc-4a03-98a9-589c0045db0c	04bf8d40-6169-482f-a5dc-8be84ea27846	6edf7518-f332-49f0-886d-c1c76af9e44a	\N	t	\N	2026-09-27 11:58:10.811745+00
f196e9d5-c6f9-4e39-b8cc-ef1c28f05af5	a1f0bfe7-a9c9-409a-99e3-848b9ccb8c96	cb17a8ef-3807-4d9a-a2bd-5c735c7b06a8	\N	t	\N	2026-09-27 11:58:10.811745+00
bb807834-7b04-4e74-ad84-a8484c7489a3	a1f0bfe7-a9c9-409a-99e3-848b9ccb8c96	b1c1c787-a63a-48ae-99d3-8a166cc80427	\N	t	\N	2026-09-27 11:58:10.811745+00
c7c6a676-1744-4dba-a4db-98cb464150ce	a1f0bfe7-a9c9-409a-99e3-848b9ccb8c96	c3004935-ecdf-4cba-9291-e7045bc29552	\N	t	\N	2026-09-27 11:58:10.811745+00
a7361529-8a7b-4732-a8f8-6209cda5eb73	17b9ab48-660c-49f2-bb8d-99f825a85c66	54038861-05e1-4131-91eb-e8ca032457ce	\N	t	\N	2026-09-27 11:58:10.811745+00
aad8ac3d-7675-4388-977f-c322107c6af5	25206944-f2de-4519-83ae-6c4e6769527b	b1701ae8-c9a0-49b9-abaa-0270d36aeb65	2.80	f	\N	2026-09-27 11:58:10.811745+00
bef5e3ce-be75-4e38-be0e-6958e951d16b	25206944-f2de-4519-83ae-6c4e6769527b	f746a983-c8c3-4586-a091-a2a36c91496f	2.40	f	\N	2026-09-27 11:58:10.811745+00
94e263fd-abf1-4944-b558-79b21f008fe3	25206944-f2de-4519-83ae-6c4e6769527b	66da7d9e-3341-4b65-92a1-247e2d7d4682	\N	f	\N	2026-09-27 11:58:10.811745+00
3554b5ec-b0bc-42af-9b3b-041badb53bf3	03354dd1-7bad-4fd7-86bf-1b1d57e5a8d2	b1701ae8-c9a0-49b9-abaa-0270d36aeb65	\N	t	\N	2026-09-27 11:58:10.811745+00
0ed2eb61-ab87-43ca-8338-892b06438bfb	03354dd1-7bad-4fd7-86bf-1b1d57e5a8d2	f746a983-c8c3-4586-a091-a2a36c91496f	\N	t	\N	2026-09-27 11:58:10.811745+00
8bc92184-0f28-4b0e-ac0a-99bf45910995	2c50bd62-8655-45f6-beae-6cb675f2637b	2526cd20-7cd8-4784-9f72-6147701fe4d6	3.60	t	\N	2026-09-27 11:58:10.811745+00
1ab7cd3b-fda7-4dde-aec2-a29273474f95	2c50bd62-8655-45f6-beae-6cb675f2637b	c0894749-def7-4bb8-9714-fdc1d61cbc3d	3.50	t	\N	2026-09-27 11:58:10.811745+00
e8c7bf26-80f8-4300-a333-c7d92e65b962	2c50bd62-8655-45f6-beae-6cb675f2637b	f746a983-c8c3-4586-a091-a2a36c91496f	3.60	f	\N	2026-09-27 11:58:10.811745+00
c1459941-b639-4416-aece-70df21eefff8	d4e3c01c-ccb0-4f95-aaab-4c8d56603fcb	c3004935-ecdf-4cba-9291-e7045bc29552	3.20	t	\N	2026-09-27 11:58:10.811745+00
0cb786d2-0990-4007-93e4-d5b02989c246	bbe194db-c84a-45d0-a24d-af063cfb90b5	b1c1c787-a63a-48ae-99d3-8a166cc80427	\N	t	\N	2026-09-27 11:58:10.811745+00
de860189-c669-4f30-b433-242ed5b5ce55	6e134674-4b24-4cb5-81d9-0f8861ddacce	9dd2749b-3951-47f9-80ee-be50cf283f42	\N	f	\N	2026-09-27 11:58:10.811745+00
82f72b93-ce02-4246-8c90-0585a577a61a	6e134674-4b24-4cb5-81d9-0f8861ddacce	0e1b9120-8a9d-4004-96a1-e29e160a2bd7	\N	t	\N	2026-09-27 11:58:10.811745+00
\.


--
-- Data for Name: shifts; Type: TABLE DATA; Schema: public; Owner: xama_user
--

COPY public.shifts (id, shift_date, site, role, start_time, end_time, capacity, notes, created_at) FROM stdin;
6ca9b406-1d82-4ac7-b8fe-21599ca3c583	2026-09-27	reus	vehiculo	09:00:00	13:00:00	3	\N	2026-09-27 11:58:10.787355+00
89fb87a0-66a8-431c-a30a-2a84bafa57bb	2026-09-27	reus	clasificacion	09:00:00	13:00:00	3	\N	2026-09-27 11:58:10.787355+00
7b4fed7f-5091-4d9a-b6fc-17130bd8a347	2026-09-27	reus	cestas	09:00:00	13:00:00	4	\N	2026-09-27 11:58:10.787355+00
73a96d0d-db19-4b88-b126-192ac4a1ff8f	2026-09-27	reus	puerta	09:00:00	13:00:00	4	\N	2026-09-27 11:58:10.787355+00
9a170a32-3252-45b3-9bb2-c486dab81c77	2026-09-27	tarragona	vehiculo	09:00:00	13:00:00	3	\N	2026-09-27 11:58:10.787355+00
7178f823-f539-4e70-aef6-0ece48a52f20	2026-09-27	tarragona	clasificacion	09:00:00	13:00:00	4	\N	2026-09-27 11:58:10.787355+00
2c3f7edc-ddf5-4a9e-8060-4e06e00c0629	2026-09-27	tarragona	cestas	09:00:00	13:00:00	2	\N	2026-09-27 11:58:10.787355+00
1ea57f26-35fc-4376-b1d6-0852c4d5cbe0	2026-09-27	tarragona	puerta	09:00:00	13:00:00	4	\N	2026-09-27 11:58:10.787355+00
f18d0f63-96e8-43bf-9d47-12be6ed37272	2026-09-28	reus	vehiculo	09:00:00	13:00:00	2	\N	2026-09-27 11:58:10.787355+00
35fc19ac-11ad-45b5-9746-ac963b2884cb	2026-09-28	reus	clasificacion	09:00:00	13:00:00	2	\N	2026-09-27 11:58:10.787355+00
1fae6446-4649-45f6-8f70-b399f95d4f3d	2026-09-28	reus	cestas	09:00:00	13:00:00	2	\N	2026-09-27 11:58:10.787355+00
f32d39da-caed-4469-8bc3-14ad43c320c0	2026-09-28	reus	puerta	09:00:00	13:00:00	4	\N	2026-09-27 11:58:10.787355+00
4015d9f8-48b7-4ecf-92cb-faf11d0405c7	2026-09-28	tarragona	vehiculo	09:00:00	13:00:00	3	\N	2026-09-27 11:58:10.787355+00
ad5472d1-23a7-4fff-864c-769bfbacee27	2026-09-28	tarragona	clasificacion	09:00:00	13:00:00	3	\N	2026-09-27 11:58:10.787355+00
425460c6-a3ea-434c-bf4d-5b96457caf5e	2026-09-28	tarragona	cestas	09:00:00	13:00:00	4	\N	2026-09-27 11:58:10.787355+00
2634db19-702d-44d1-bb8b-e1d074fa0223	2026-09-28	tarragona	puerta	09:00:00	13:00:00	2	\N	2026-09-27 11:58:10.787355+00
c29a7b3b-e907-408f-823d-23887fde6a9d	2026-09-29	reus	vehiculo	09:00:00	13:00:00	4	\N	2026-09-27 11:58:10.787355+00
f885b9bb-0743-441d-b387-7c7faf9b6f09	2026-09-29	reus	clasificacion	09:00:00	13:00:00	3	\N	2026-09-27 11:58:10.787355+00
5f1fa009-afc6-4c78-96c2-ea0710a327ff	2026-09-29	reus	cestas	09:00:00	13:00:00	4	\N	2026-09-27 11:58:10.787355+00
fd5e6b98-bccc-4df3-aab6-83e156ad6e43	2026-09-29	reus	puerta	09:00:00	13:00:00	4	\N	2026-09-27 11:58:10.787355+00
43bb0271-02fe-4303-994c-e36ec942335e	2026-09-29	tarragona	vehiculo	09:00:00	13:00:00	3	\N	2026-09-27 11:58:10.787355+00
874c130e-63aa-4d04-b011-d7048057593e	2026-09-29	tarragona	clasificacion	09:00:00	13:00:00	3	\N	2026-09-27 11:58:10.787355+00
80d3a98f-00e8-44d8-93dd-4c4e6935c8d6	2026-09-29	tarragona	cestas	09:00:00	13:00:00	2	\N	2026-09-27 11:58:10.787355+00
d66523e8-67aa-434e-a336-aa993636c546	2026-09-29	tarragona	puerta	09:00:00	13:00:00	2	\N	2026-09-27 11:58:10.787355+00
fc999197-139c-477b-a78f-ddcc20b534c8	2026-09-30	reus	vehiculo	09:00:00	13:00:00	3	\N	2026-09-27 11:58:10.787355+00
4e3b1b26-5255-44e6-af74-da4182bee017	2026-09-30	reus	clasificacion	09:00:00	13:00:00	2	\N	2026-09-27 11:58:10.787355+00
efa4c422-24ec-4d47-9ad7-2fe1c2ccf97e	2026-09-30	reus	cestas	09:00:00	13:00:00	3	\N	2026-09-27 11:58:10.787355+00
24f50b41-98a0-44a5-a2bf-e8bcbac48a91	2026-09-30	reus	puerta	09:00:00	13:00:00	4	\N	2026-09-27 11:58:10.787355+00
e7da82da-552a-452e-9ae4-7ed7e874a110	2026-09-30	tarragona	vehiculo	09:00:00	13:00:00	2	\N	2026-09-27 11:58:10.787355+00
5513d1b1-21f3-4f74-8cc1-459592a79f49	2026-09-30	tarragona	clasificacion	09:00:00	13:00:00	3	\N	2026-09-27 11:58:10.787355+00
5c567893-982e-4eaa-b0c2-3d082351d642	2026-09-30	tarragona	cestas	09:00:00	13:00:00	4	\N	2026-09-27 11:58:10.787355+00
52c112b1-58ea-46f9-86d8-965def76af56	2026-09-30	tarragona	puerta	09:00:00	13:00:00	4	\N	2026-09-27 11:58:10.787355+00
f9a0ef18-158c-45de-a521-0eb93d8d2a85	2026-10-01	reus	vehiculo	09:00:00	13:00:00	3	\N	2026-09-27 11:58:10.787355+00
577b58d5-fa4f-4503-98a9-60fb1caeb6e1	2026-10-01	reus	clasificacion	09:00:00	13:00:00	3	\N	2026-09-27 11:58:10.787355+00
0c11c97d-9549-4b8d-85cc-58e974fa569b	2026-10-01	reus	cestas	09:00:00	13:00:00	4	\N	2026-09-27 11:58:10.787355+00
ca2a672c-cdfb-4ce3-8dd1-d64eeabe8a0d	2026-10-01	reus	puerta	09:00:00	13:00:00	4	\N	2026-09-27 11:58:10.787355+00
0198e390-eeb4-4b59-854d-1b16e833cfeb	2026-10-01	tarragona	vehiculo	09:00:00	13:00:00	3	\N	2026-09-27 11:58:10.787355+00
a7b8891a-eff9-4e63-a50c-691efdfa8a40	2026-10-01	tarragona	clasificacion	09:00:00	13:00:00	3	\N	2026-09-27 11:58:10.787355+00
30abe2f9-7cb0-470f-a1a4-cc9fe17202a1	2026-10-01	tarragona	cestas	09:00:00	13:00:00	4	\N	2026-09-27 11:58:10.787355+00
50cbd581-b744-4cfa-b7c0-c8aa8c5d887b	2026-10-01	tarragona	puerta	09:00:00	13:00:00	4	\N	2026-09-27 11:58:10.787355+00
9271214e-d5e5-459a-8583-c5fc08b5a02c	2026-10-02	reus	vehiculo	09:00:00	13:00:00	3	\N	2026-09-27 11:58:10.787355+00
da51f134-3334-47af-b7fd-6fa6b5cc86f8	2026-10-02	reus	clasificacion	09:00:00	13:00:00	3	\N	2026-09-27 11:58:10.787355+00
454bee35-349b-403a-8f01-41ef21f304de	2026-10-02	reus	cestas	09:00:00	13:00:00	4	\N	2026-09-27 11:58:10.787355+00
cface6b5-12ba-4e08-b3ec-108bd00e1830	2026-10-02	reus	puerta	09:00:00	13:00:00	3	\N	2026-09-27 11:58:10.787355+00
f2b0f9d4-082a-4ad9-b6fb-3e14acdc144a	2026-10-02	tarragona	vehiculo	09:00:00	13:00:00	3	\N	2026-09-27 11:58:10.787355+00
04bf8d40-6169-482f-a5dc-8be84ea27846	2026-10-02	tarragona	clasificacion	09:00:00	13:00:00	3	\N	2026-09-27 11:58:10.787355+00
a1f0bfe7-a9c9-409a-99e3-848b9ccb8c96	2026-10-02	tarragona	cestas	09:00:00	13:00:00	3	\N	2026-09-27 11:58:10.787355+00
17b9ab48-660c-49f2-bb8d-99f825a85c66	2026-10-02	tarragona	puerta	09:00:00	13:00:00	2	\N	2026-09-27 11:58:10.787355+00
203c0fa2-0b10-4fa6-ba02-befd769a27d6	2026-10-03	reus	vehiculo	09:00:00	13:00:00	2	\N	2026-09-27 11:58:10.787355+00
25206944-f2de-4519-83ae-6c4e6769527b	2026-10-03	reus	clasificacion	09:00:00	13:00:00	4	\N	2026-09-27 11:58:10.787355+00
03354dd1-7bad-4fd7-86bf-1b1d57e5a8d2	2026-10-03	reus	cestas	09:00:00	13:00:00	2	\N	2026-09-27 11:58:10.787355+00
2c50bd62-8655-45f6-beae-6cb675f2637b	2026-10-03	reus	puerta	09:00:00	13:00:00	3	\N	2026-09-27 11:58:10.787355+00
d4e3c01c-ccb0-4f95-aaab-4c8d56603fcb	2026-10-03	tarragona	vehiculo	09:00:00	13:00:00	2	\N	2026-09-27 11:58:10.787355+00
bbe194db-c84a-45d0-a24d-af063cfb90b5	2026-10-03	tarragona	clasificacion	09:00:00	13:00:00	4	\N	2026-09-27 11:58:10.787355+00
1432e987-5ec0-4ed9-8888-b091f9c1dc05	2026-10-03	tarragona	cestas	09:00:00	13:00:00	4	\N	2026-09-27 11:58:10.787355+00
6e134674-4b24-4cb5-81d9-0f8861ddacce	2026-10-03	tarragona	puerta	09:00:00	13:00:00	4	\N	2026-09-27 11:58:10.787355+00
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: xama_user
--

COPY public.users (id, email, password_hash, full_name, role_id, site, active, created_at) FROM stdin;
829f74fe-8709-4fb9-b41c-7057ed152626	admin@xama.local	$2b$12$qV7r.f0KXjfafffmIhZhr.GMtpyd7xqVrr.YgapJJ6YM9Yvg9fFlq	Administrador XAMA	1	\N	t	2026-09-27 11:57:46.992737+00
0a3b9688-9548-4ae2-b06b-33da7cb3c30e	coord.reus@xama.local	$2b$12$H9Mz254XWyz5QAYWgJnGv.OvjqOi5YRiMTTqquHeZcl2nY7dw93aK	Coordinador Reus	2	reus	t	2026-09-27 11:58:00.33554+00
bef99830-d086-48ff-a1af-984270fa89db	coord.tarragona@xama.local	$2b$12$e/hdKibQEFspcv0knahYeuCsZRZsAb.9B83VKr2oq9NjCO894j3cO	Coordinador Tarragona	3	tarragona	t	2026-09-27 11:58:00.33554+00
79bb1935-2c17-4118-8cc1-691212012133	ss@xama.local	$2b$12$PC2vB9GhBZWqjw1ACSItzuv2.pLde9iJJ5hvpsPKW0cM/8YrUd272	Servicios Sociales	5	\N	t	2026-09-27 11:58:00.33554+00
c0894749-def7-4bb8-9714-fdc1d61cbc3d	vol.reus1@xama.local	$2b$12$lp1q9CdrUg4n.mSUJrEAy.V44VJ7ZJcJmnh/1qfAepLNYdp5zbeHK	Rocío Sánchez	4	reus	t	2026-09-27 11:58:01.305319+00
13e0ec78-5c85-4202-af14-c51288fa9b7d	vol.reus2@xama.local	$2b$12$QpAajWJLnLpyHt.zr7TzsuDHr.IFTr4jkihxCgmE2DAVKQNd3kj6i	Ana Díaz	4	reus	t	2026-09-27 11:58:01.305319+00
f5c04ce2-2768-4047-8026-12e940f96be1	vol.reus3@xama.local	$2b$12$a.W8ESTBM1a8TgKuc0F6gexowAgpaFJzMAVX8Ysop/7SJU0wMCJ0u	Elena Ruiz	4	reus	t	2026-09-27 11:58:01.305319+00
ec476a00-2ab3-4eb9-9a23-e060d3855c20	vol.reus4@xama.local	$2b$12$jrrYWztihAe0c8ks.pYALOIJqvmNtJ4ZZi0I2Koyh.x29xvY.5vz2	Sofía Sánchez	4	reus	t	2026-09-27 11:58:01.305319+00
66da7d9e-3341-4b65-92a1-247e2d7d4682	vol.reus5@xama.local	$2b$12$GgjM8gdjyzwfQM2D9tYjqerEQTsuXN0NNyyYj7gOGGKdFE3C9vVk2	Silvia Castro	4	reus	t	2026-09-27 11:58:01.305319+00
0c5065e8-f021-4b1b-99b8-e266270cf484	vol.reus6@xama.local	$2b$12$RfWjP83kuGtG29rU9bGuzONw7iMbItm81YRKWNdhOAG2n6uhJU0gy	Carmen Jiménez	4	reus	t	2026-09-27 11:58:01.305319+00
296d2a32-284c-465c-9b7a-ac720cbaada6	vol.reus7@xama.local	$2b$12$tt4BoONZk/wB0X3cR74MnehwSjI0qQ/MrrZTAo2qdY6dzJA8aWSUi	María García	4	reus	t	2026-09-27 11:58:01.305319+00
67d7802c-2658-418a-bb33-4873fdc63992	vol.reus8@xama.local	$2b$12$DCpnTcw9wwHhnucKsk383Ou36IonYG3pxUmDvRTfVabhjmJ5TWpD6	Carmen Gómez	4	reus	t	2026-09-27 11:58:01.305319+00
2526cd20-7cd8-4784-9f72-6147701fe4d6	vol.reus9@xama.local	$2b$12$L81IZ0oWs.drwPsX.HUPQO9drdx0gEhwiRExD.FrEFnOnJKeOtRFq	Elena Hernández	4	reus	t	2026-09-27 11:58:01.305319+00
f746a983-c8c3-4586-a091-a2a36c91496f	vol.reus10@xama.local	$2b$12$JYojH.Z6M8M7beEIhGZM5eCEdyzb1KRg.caJXCA4.yPWlceaLgGui	Isabel García	4	reus	t	2026-09-27 11:58:01.305319+00
a8d5f730-959a-42f8-b790-70cc4a3c80f0	vol.reus11@xama.local	$2b$12$vks6c2uINTQjzhS40MdHmuOpcZ.V0/oQNEMnOSYVA3BJ8Mgku.UGm	Cristina Gómez	4	reus	t	2026-09-27 11:58:01.305319+00
b1701ae8-c9a0-49b9-abaa-0270d36aeb65	vol.reus12@xama.local	$2b$12$DJzMx3j4Kn9cD.Qc7vlyK.xk5iWFs0ItGk3TN9gqbzUwmPeZLX6Aa	Rocío Castro	4	reus	t	2026-09-27 11:58:01.305319+00
48e414f6-e5eb-4b68-864d-43eceb9d2203	vol.reus13@xama.local	$2b$12$rbNmscnkartt0Cg9sn95.uOYc0Fu7xQUJkOalL57a3kigL7r8lKHy	Antonio Ruiz	4	reus	t	2026-09-27 11:58:01.305319+00
ebea5cfd-bb12-4dc6-856c-60b403001057	vol.reus14@xama.local	$2b$12$SEpOMPlSMBbkmhGZprKXF.Qj9HTW5YRnXmNd9vbbcXBdd97P5Wmh6	Pablo Díaz	4	reus	t	2026-09-27 11:58:01.305319+00
045f636b-55dd-4fc9-b216-34cbe41545ca	vol.reus15@xama.local	$2b$12$n1Q1FsfQhehg30b7a3nWF.KNSursDzXZPCvmHEG1PHgxOm1WbcV1K	Ana Fernández	4	reus	t	2026-09-27 11:58:01.305319+00
26e335c0-a201-4a5c-ae10-e2792a17c806	vol.reus16@xama.local	$2b$12$mhws3aouSf1I4ESAY2lb8uWSaS8bc/a//Yd76Ql2TiCBbFDaDljXW	Antonio Vázquez	4	reus	t	2026-09-27 11:58:01.305319+00
d4f37236-69cb-46a1-a60e-1e7d564ac014	vol.tgn1@xama.local	$2b$12$qKR8KJ8Jje0r3rhMwu/8zuhDjsyIfcBPS0.PdWngqmh2oibcqVkGi	Javier Rodríguez	4	tarragona	t	2026-09-27 11:58:01.305319+00
b7b096bf-2720-496e-8db9-bec37c8433a8	vol.tgn2@xama.local	$2b$12$d8JgQuJzkTKpqBYrFilz9ucOAOtAtsemifUFYjroLMbdRlYd3xXZ.	Laura Vázquez	4	tarragona	t	2026-09-27 11:58:01.305319+00
6edf7518-f332-49f0-886d-c1c76af9e44a	vol.tgn3@xama.local	$2b$12$2EgM9AGzbPC8KvXpjSLT6u8YOwqZS38ynFTG7jh91pHKUA5F4.vsG	Lucía López	4	tarragona	t	2026-09-27 11:58:01.305319+00
c3004935-ecdf-4cba-9291-e7045bc29552	vol.tgn4@xama.local	$2b$12$0o6AVesg7spZnB3BSf3Xe.NnZcio27t4/9XZ4EEAUi4bAAKHSnWr6	José Sánchez	4	tarragona	t	2026-09-27 11:58:01.305319+00
34721c74-d837-4355-850d-85d7a3fc15aa	vol.tgn5@xama.local	$2b$12$NBd6F84mmdz1HYLn8.yP6uRtXhf78S/R6lt5gB0ATLpH.cuah9mjW	David Ramos	4	tarragona	t	2026-09-27 11:58:01.305319+00
6c5ae079-39f7-432b-a37b-e9743394f8ef	vol.tgn6@xama.local	$2b$12$f0Fs1NIt8QuH45O3MfLlwer5SWBjiCoO.FSaYn/O8Vx1WOBPEXsQG	Isabel Díaz	4	tarragona	t	2026-09-27 11:58:01.305319+00
3eb35f4e-2dde-4b9d-8103-1012d06f82c1	vol.tgn7@xama.local	$2b$12$ZtHO64qRmNYlqxKztBjrwerQDg7IQDNrpT3jFT6G.T3B5oifhrgXW	María Álvarez	4	tarragona	t	2026-09-27 11:58:01.305319+00
0e1b9120-8a9d-4004-96a1-e29e160a2bd7	vol.tgn8@xama.local	$2b$12$A0to5n/rjcR7RU6t1vyqf.jHY51WVc.t0aIAJaKd04qhreSdBJez6	Cristina Sánchez	4	tarragona	t	2026-09-27 11:58:01.305319+00
2b3825ad-a43c-4d75-b3d3-a34b2e04cbae	vol.tgn9@xama.local	$2b$12$JmjXSmKxnC9.JM.flrtW/ebpKHF.ljROf9KE0fstxvxjDDLxv.x6C	José López	4	tarragona	t	2026-09-27 11:58:01.305319+00
cb17a8ef-3807-4d9a-a2bd-5c735c7b06a8	vol.tgn10@xama.local	$2b$12$bi70cdqR54vHu04zoSYjvOVEcAgy1SnywD6.auf0YUTYwdGR.Ay9m	Cristina Torres	4	tarragona	t	2026-09-27 11:58:01.305319+00
b1c1c787-a63a-48ae-99d3-8a166cc80427	vol.tgn11@xama.local	$2b$12$5aSoBp5JYehKUOEhgMkH6O0UdJHazP0T2qD0uqOHLlIgHtsnECtia	Rocío Ramos	4	tarragona	t	2026-09-27 11:58:01.305319+00
e2d92b3d-9023-4d2f-83f0-1b31cf1511a1	vol.tgn12@xama.local	$2b$12$L6APrUOBh9mtWXd94NeIX.qLxRLYEf4iSNkHJxAo1SjPEmVkc6nIy	Patricia Gómez	4	tarragona	t	2026-09-27 11:58:01.305319+00
9dd2749b-3951-47f9-80ee-be50cf283f42	vol.tgn13@xama.local	$2b$12$kkMkppqllDQ.XtSLXXms1uB.s7KrTqN9D.MmO/sN9GU5ZNq.NsiM.	Carmen Martínez	4	tarragona	t	2026-09-27 11:58:01.305319+00
68ad1573-01cc-4d4e-ae39-c91c17eb062f	vol.tgn14@xama.local	$2b$12$gV2D3eMTDyel1C6NpP4j6eOKrUbHNXB0QG3GyJR3tjifgqXukwx7y	Silvia Ruiz	4	tarragona	t	2026-09-27 11:58:01.305319+00
54038861-05e1-4131-91eb-e8ca032457ce	vol.tgn15@xama.local	$2b$12$ze5GYvxp3vjWN9pct.4kE.55NUp7FjRuQ3nXfKxJeTulwOsRKvwVi	Carlos López	4	tarragona	t	2026-09-27 11:58:01.305319+00
\.


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: xama_user
--

SELECT pg_catalog.setval('public.roles_id_seq', 5, true);


--
-- Name: batches batches_pkey; Type: CONSTRAINT; Schema: public; Owner: xama_user
--

ALTER TABLE ONLY public.batches
    ADD CONSTRAINT batches_pkey PRIMARY KEY (id);


--
-- Name: deliveries deliveries_pkey; Type: CONSTRAINT; Schema: public; Owner: xama_user
--

ALTER TABLE ONLY public.deliveries
    ADD CONSTRAINT deliveries_pkey PRIMARY KEY (id);


--
-- Name: derivations derivations_pkey; Type: CONSTRAINT; Schema: public; Owner: xama_user
--

ALTER TABLE ONLY public.derivations
    ADD CONSTRAINT derivations_pkey PRIMARY KEY (id);


--
-- Name: derivations derivations_reference_code_key; Type: CONSTRAINT; Schema: public; Owner: xama_user
--

ALTER TABLE ONLY public.derivations
    ADD CONSTRAINT derivations_reference_code_key UNIQUE (reference_code);


--
-- Name: families families_pkey; Type: CONSTRAINT; Schema: public; Owner: xama_user
--

ALTER TABLE ONLY public.families
    ADD CONSTRAINT families_pkey PRIMARY KEY (id);


--
-- Name: families families_reference_code_key; Type: CONSTRAINT; Schema: public; Owner: xama_user
--

ALTER TABLE ONLY public.families
    ADD CONSTRAINT families_reference_code_key UNIQUE (reference_code);


--
-- Name: nevera_rations nevera_rations_date_key; Type: CONSTRAINT; Schema: public; Owner: xama_user
--

ALTER TABLE ONLY public.nevera_rations
    ADD CONSTRAINT nevera_rations_date_key UNIQUE (date);


--
-- Name: nevera_rations nevera_rations_pkey; Type: CONSTRAINT; Schema: public; Owner: xama_user
--

ALTER TABLE ONLY public.nevera_rations
    ADD CONSTRAINT nevera_rations_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: xama_user
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: roles roles_name_key; Type: CONSTRAINT; Schema: public; Owner: xama_user
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key UNIQUE (name);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: xama_user
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: shift_assignments shift_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: xama_user
--

ALTER TABLE ONLY public.shift_assignments
    ADD CONSTRAINT shift_assignments_pkey PRIMARY KEY (id);


--
-- Name: shift_assignments shift_assignments_shift_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: xama_user
--

ALTER TABLE ONLY public.shift_assignments
    ADD CONSTRAINT shift_assignments_shift_id_user_id_key UNIQUE (shift_id, user_id);


--
-- Name: shifts shifts_pkey; Type: CONSTRAINT; Schema: public; Owner: xama_user
--

ALTER TABLE ONLY public.shifts
    ADD CONSTRAINT shifts_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: xama_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: xama_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: batches batches_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: xama_user
--

ALTER TABLE ONLY public.batches
    ADD CONSTRAINT batches_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: deliveries deliveries_family_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: xama_user
--

ALTER TABLE ONLY public.deliveries
    ADD CONSTRAINT deliveries_family_id_fkey FOREIGN KEY (family_id) REFERENCES public.families(id) ON DELETE CASCADE;


--
-- Name: deliveries deliveries_volunteer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: xama_user
--

ALTER TABLE ONLY public.deliveries
    ADD CONSTRAINT deliveries_volunteer_id_fkey FOREIGN KEY (volunteer_id) REFERENCES public.users(id);


--
-- Name: shift_assignments shift_assignments_shift_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: xama_user
--

ALTER TABLE ONLY public.shift_assignments
    ADD CONSTRAINT shift_assignments_shift_id_fkey FOREIGN KEY (shift_id) REFERENCES public.shifts(id) ON DELETE CASCADE;


--
-- Name: shift_assignments shift_assignments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: xama_user
--

ALTER TABLE ONLY public.shift_assignments
    ADD CONSTRAINT shift_assignments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: users users_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: xama_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id);


--
-- PostgreSQL database dump complete
--

\unrestrict 8dXrqq7ZsxZNJSj4SFDDyzn1XyHSdHUJIkm7CiR6KCVdwpMBaddyB5REf6Yx2QB

